source('afRemover.R')
library(EBImage)

#------------------------#
# Step 1: Read in images #
#------------------------#

im1 <- readImage('1-1.tif')
im2 <- readImage('1-2.tif')

#----------------------------------#
# Step 2: Obtain mask for analysis #
#----------------------------------#

## Approach 1: Read in an already generated mask
mask <- readImage('mask.tif')

## Approach 2: Create mask using EBImage
# im1Blurred <- gblur(im1, sigma = 2) # Blur both channels before thresholding
# im2Blurred <- gblur(im1, sigma = 2)
# 
# im1Threshold <- otsu(im1Blurred, levels = 2^16) # Threshold 16 bit images using Otsu
# im2Threshold <- otsu(im2Blurred, levels = 2^16)
# 
# mask <- im1Blurred>im1Threshold & im2Blurred>im2Threshold

## Label mask
mask <- bwlabel(mask)

#-----------------------------------------#
# Step 3: Autofluorescence Classification #
#-----------------------------------------#

df <- afMeasure(im1, im2, mask)

## Correlation only
# afMask <- afIdentify(mask, df, minSize = 100, maxSize = Inf, corr = 0.6)

## Clustering with given k
# afMask <- afIdentify(mask, df, minSize = 100, maxSize = Inf, k = 6)

## Clustering with estimated k
afMask <- afIdentify(mask, df, minSize = 100, maxSize = Inf, k = 20, kAuto = TRUE)

## Clustering and correlation
# afMask <- afIdentify(mask, df, minSize = 100, maxSize = Inf, corr = 0.6, k = 6)
# OR
# afMask <- afIdentify(mask, df, minSize = 100, maxSize = Inf, corr = 0.6, k = 20, kAuto = TRUE)

#---------------------------------#
# Step 4: Remove Autofluorescence #
#---------------------------------#

im1AFRemoved <- im1
im2AFRemoved <- im2
im1AFRemoved[afMask != 0] <- 0
im2AFRemoved[afMask != 0] <- 0
